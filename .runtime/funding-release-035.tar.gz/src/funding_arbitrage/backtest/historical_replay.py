"""No-look-ahead replay over historical candles and settled funding events."""

from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from funding_arbitrage.backtest.database_replay import PaperReplayDataset
from funding_arbitrage.backtest.events import (
    BacktestEvent,
    FillEvent,
    FundingEvent,
    MarketEvent,
    OpportunityEvent,
    PositionEvent,
)
from funding_arbitrage.config import Settings
from funding_arbitrage.database.models import (
    FundingHistoryRecord,
    InstrumentRecord,
    MarketCandleRecord,
)
from funding_arbitrage.exchanges.base.models import (
    FundingHistoryPoint,
    FundingSnapshot,
    InstrumentType,
    NormalizedInstrument,
    OrderBook,
    OrderBookLevel,
    Ticker,
)
from funding_arbitrage.market_data.collector import MarketSnapshot
from funding_arbitrage.opportunity.calculator import CostEngine
from funding_arbitrage.opportunity.engine import OpportunityEngine
from funding_arbitrage.opportunity.filters import OpportunityFilterConfig
from funding_arbitrage.opportunity.models import FeeSchedule, Opportunity, SizeQuote
from funding_arbitrage.opportunity.settlement import (
    settlement_entry_allowed,
    target_settlements,
)
from funding_arbitrage.risk.engine import RiskEngine


@dataclass(frozen=True)
class HistoricalDataset:
    instruments: list[NormalizedInstrument]
    candles: list[MarketCandleRecord]
    funding: list[FundingHistoryPoint]
    dataset_version: str
    coverage: dict[str, object]


@dataclass
class _ReplayPosition:
    position_id: str
    opportunity: Opportunity
    capital: Decimal
    opened_at: datetime
    entry_a: Decimal
    entry_b: Decimal
    target_settlements: tuple[datetime, ...]
    funding_events: int = 0
    funding_pnl: Decimal = Decimal("0")
    entry_fees: Decimal = Decimal("0")
    entry_spread: Decimal = Decimal("0")
    entry_slippage: Decimal = Decimal("0")


class HistoricalMarketReplay:
    """Load a canonical DB slice and simulate profiles from identical inputs."""

    async def load(
        self, session: AsyncSession, start: datetime, end: datetime
    ) -> HistoricalDataset:
        start = _utc(start)
        end = _utc(end)
        if start >= end:
            raise ValueError("start must be before end")
        candle_rows = list(
            (
                await session.execute(
                    select(MarketCandleRecord)
                    .where(
                        MarketCandleRecord.close_time >= start,
                        MarketCandleRecord.close_time < end,
                        MarketCandleRecord.is_closed.is_(True),
                    )
                    .order_by(
                        MarketCandleRecord.close_time,
                        MarketCandleRecord.exchange,
                        MarketCandleRecord.symbol,
                        MarketCandleRecord.instrument_type,
                    )
                )
            ).scalars()
        )
        funding_rows = list(
            (
                await session.execute(
                    select(FundingHistoryRecord)
                    .where(
                        FundingHistoryRecord.funding_timestamp >= start - timedelta(days=30),
                        FundingHistoryRecord.funding_timestamp < end,
                    )
                    .order_by(
                        FundingHistoryRecord.funding_timestamp,
                        FundingHistoryRecord.exchange,
                        FundingHistoryRecord.symbol,
                    )
                )
            ).scalars()
        )
        identities = {
            (row.exchange, row.symbol, row.instrument_type) for row in candle_rows
        }
        instrument_rows = list((await session.execute(select(InstrumentRecord))).scalars())
        instruments = [
            _instrument(row)
            for row in instrument_rows
            if (row.exchange, row.exchange_symbol, row.instrument_type) in identities
        ]
        perpetual_symbols = {
            (row.exchange, row.symbol)
            for row in candle_rows
            if row.instrument_type == InstrumentType.PERPETUAL.value
        }
        funding = _funding_points(funding_rows, perpetual_symbols)
        version = _dataset_digest(candle_rows, funding)
        return HistoricalDataset(
            instruments=instruments,
            candles=candle_rows,
            funding=funding,
            dataset_version=f"market-db-sha256:{version}",
            coverage=_coverage(candle_rows, funding, start, end),
        )

    def simulate(
        self,
        dataset: HistoricalDataset,
        profile: str,
        initial_capital: Decimal,
        settings: Settings,
    ) -> PaperReplayDataset:
        if profile not in {"baseline", "candidate"}:
            raise ValueError("profile must be baseline or candidate")
        if initial_capital <= 0:
            raise ValueError("initial_capital must be positive")
        engine = _opportunity_engine(settings, profile)
        risk_engine = RiskEngine()
        candles_by_time: dict[datetime, list[MarketCandleRecord]] = defaultdict(list)
        for candle in dataset.candles:
            candles_by_time[_candle_timestamp(candle)].append(candle)
        funding_by_time: dict[datetime, list[FundingHistoryPoint]] = defaultdict(list)
        funding_by_symbol: dict[tuple[str, str], list[FundingHistoryPoint]] = defaultdict(list)
        for point in dataset.funding:
            funding_by_time[point.funding_timestamp].append(point)
            funding_by_symbol[(point.exchange, point.symbol)].append(point)
        for points in funding_by_symbol.values():
            points.sort(key=lambda value: value.funding_timestamp)
        settlement_times = sorted(funding_by_time)
        settlement_cursor = 0

        events: list[BacktestEvent] = []
        if dataset.candles:
            first = min(dataset.candles, key=lambda item: _utc(item.open_time))
            last = max(dataset.candles, key=_candle_timestamp)
            events.extend(
                [
                    MarketEvent(
                        event_id=f"{profile}:dataset-start",
                        timestamp=_utc(first.open_time),
                        exchange=first.exchange,
                        symbol=first.symbol,
                        price=first.open,
                    ),
                    MarketEvent(
                        event_id=f"{profile}:dataset-end",
                        timestamp=_candle_timestamp(last),
                        exchange=last.exchange,
                        symbol=last.symbol,
                        price=last.close,
                    ),
                ]
            )
        attribution: dict[str, dict[str, dict[str, Decimal]]] = {
            "strategy": {},
            "exchange": {},
            "asset": {},
        }
        positions: dict[str, _ReplayPosition] = {}
        last_prices: dict[tuple[str, str, str], Decimal] = {}
        realized = Decimal("0")
        serial = 0
        for timestamp in sorted(candles_by_time):
            current_candles = candles_by_time[timestamp]
            for candle in current_candles:
                last_prices[(candle.exchange, candle.symbol, candle.instrument_type)] = candle.close
                events.append(
                    MarketEvent(
                        event_id=(
                            f"{profile}:market:{candle.exchange}:{candle.symbol}:"
                            f"{candle.instrument_type}:{_utc(candle.open_time).isoformat()}"
                        ),
                        timestamp=timestamp,
                        exchange=candle.exchange,
                        symbol=candle.symbol,
                        price=candle.close,
                        mark_price=candle.close,
                    )
                )
            while (
                settlement_cursor < len(settlement_times)
                and settlement_times[settlement_cursor] <= timestamp
            ):
                funding_time = settlement_times[settlement_cursor]
                settlement_cursor += 1
                payments = funding_by_time[funding_time]
                for point in payments:
                    for position in positions.values():
                        pnl = _funding_payment(position, point)
                        if pnl is None:
                            continue
                        position.funding_events += 1
                        position.funding_pnl += pnl
                        realized += pnl
                        events.append(
                            FundingEvent(
                                event_id=f"{profile}:funding:{position.position_id}:{point.exchange}:{point.symbol}:{funding_time.isoformat()}",
                                timestamp=funding_time,
                                exchange=point.exchange,
                                symbol=point.symbol,
                                rate=point.funding_rate,
                                notional=position.capital,
                                pnl=pnl,
                            )
                        )
            snapshot = _snapshot(
                dataset.instruments,
                current_candles,
                funding_by_symbol,
                timestamp,
            )
            opportunities = engine.scan(snapshot)
            by_key = {_opportunity_key(item): item for item in opportunities}
            for key, position in list(positions.items()):
                current = by_key.get(key)
                age = timestamp - position.opened_at
                target_received = position.funding_events > 0
                adverse_basis = _current_market_pnl(position, last_prices) <= -(
                    position.capital * settings.paper_max_adverse_basis_percent
                )
                should_close = age >= timedelta(hours=24) if profile == "baseline" else (
                    age >= timedelta(hours=72)
                    or adverse_basis
                    or (target_received and (current is None or current.net_edge <= 0))
                    or (
                        current is not None
                        and _funding_sign_changed(position.opportunity, current)
                    )
                )
                if should_close:
                    realized += _close_position(
                        position, timestamp, last_prices, events, attribution
                    )
                    positions.pop(key)
            locked = sum(
                position.capital * Decimal(_venue_count(position.opportunity))
                for position in positions.values()
            )
            available = initial_capital + realized - locked
            occupied_assets = {position.opportunity.asset for position in positions.values()}
            for opportunity in opportunities:
                if len(positions) >= 10 or opportunity.asset in occupied_assets:
                    continue
                quote = _select_quote(
                    opportunity,
                    profile,
                    available,
                    initial_capital,
                    positions,
                    snapshot,
                    timestamp,
                    risk_engine,
                    settings,
                )
                if quote is None:
                    continue
                required = quote.capital * Decimal(_venue_count(opportunity))
                if required > available * Decimal("0.8"):
                    continue
                serial += 1
                position_id = f"{profile}-{serial:08d}"
                targets = _target_settlements(opportunity, snapshot, timestamp)
                position = _ReplayPosition(
                    position_id=position_id,
                    opportunity=opportunity,
                    capital=quote.capital,
                    opened_at=timestamp,
                    entry_a=opportunity.price_a,
                    entry_b=opportunity.price_b,
                    target_settlements=targets,
                    entry_fees=quote.costs.entry_fees,
                    entry_spread=quote.costs.entry_spread,
                    entry_slippage=quote.costs.entry_slippage,
                )
                key = _opportunity_key(opportunity)
                positions[key] = position
                occupied_assets.add(opportunity.asset)
                entry_cost = (
                    quote.costs.entry_fees
                    + quote.costs.entry_spread
                    + quote.costs.entry_slippage
                    + quote.costs.legging_cost
                )
                realized -= entry_cost
                available -= required + entry_cost
                events.extend(
                    [
                        OpportunityEvent(
                            event_id=f"{profile}:opportunity:{position_id}",
                            timestamp=timestamp,
                            opportunity_id=position_id,
                            net_edge=opportunity.net_edge,
                        ),
                        FillEvent(
                            event_id=f"{profile}:entry:{position_id}",
                            timestamp=timestamp,
                            position_id=position_id,
                            notional=quote.capital * Decimal("2"),
                            fee=quote.costs.entry_fees,
                            spread=quote.costs.entry_spread,
                            slippage=(
                                quote.costs.entry_slippage
                                + quote.costs.legging_cost
                            ),
                        ),
                        PositionEvent(
                            event_id=f"{profile}:open:{position_id}",
                            timestamp=timestamp,
                            position_id=position_id,
                            state="OPEN",
                        ),
                    ]
                )
        if candles_by_time:
            end_at = max(candles_by_time)
            for position in positions.values():
                _close_position(position, end_at, last_prices, events, attribution)
        return PaperReplayDataset(
            events=events,
            dataset_version=f"{dataset.dataset_version}:{profile}",
            attribution=attribution,
            position_count=serial,
            observation_start=(
                min(item.close_time for item in dataset.candles)
                if dataset.candles
                else None
            ),
            observation_end=(
                max(item.close_time for item in dataset.candles)
                if dataset.candles
                else None
            ),
        )


def _funding_points(
    rows: list[FundingHistoryRecord],
    perpetual_symbols: set[tuple[str, str]],
) -> list[FundingHistoryPoint]:
    return [
        FundingHistoryPoint(
            exchange=row.exchange,
            symbol=row.symbol,
            funding_rate=row.funding_rate,
            funding_timestamp=_utc(row.funding_timestamp),
            mark_price=row.mark_price,
        )
        for row in rows
        if (row.exchange, row.symbol) in perpetual_symbols
    ]


def _opportunity_engine(settings: Settings, profile: str) -> OpportunityEngine:
    return OpportunityEngine(
        cost_engine=CostEngine(
            fees={
                venue: FeeSchedule(maker_fee=fees[0], taker_fee=fees[1])
                for venue, fees in settings.fee_schedules.items()
            },
            borrowing_cost_daily=settings.scanner_borrowing_cost_daily,
            legging_cost_percent=settings.paper_legging_move_percent,
        ),
        filter_config=OpportunityFilterConfig(
            minimum_net_apr=settings.scanner_minimum_net_apr,
            minimum_liquidity_score=settings.scanner_minimum_liquidity_score,
            maximum_slippage_percent=settings.scanner_maximum_slippage_percent,
            maximum_spread_percent=settings.scanner_maximum_spread_percent,
            minimum_funding_samples=settings.scanner_minimum_funding_samples,
            minimum_opportunity_duration_seconds=0,
        ),
        funding_horizon_hours=settings.paper_funding_horizon_hours,
        allow_spot_short=settings.scanner_allow_spot_short,
        forecast_mode=profile,
    )


def _snapshot(
    instruments: list[NormalizedInstrument],
    candles: list[MarketCandleRecord],
    funding_by_symbol: dict[tuple[str, str], list[FundingHistoryPoint]],
    timestamp: datetime,
) -> MarketSnapshot:
    tickers: list[Ticker] = []
    books: dict[tuple[str, str, InstrumentType], OrderBook] = {}
    live_identities: set[tuple[str, str, InstrumentType]] = set()
    for row in candles:
        instrument_type = InstrumentType(row.instrument_type)
        spread = Decimal("0.0005")
        bid = row.close * (Decimal("1") - spread / Decimal("2"))
        ask = row.close * (Decimal("1") + spread / Decimal("2"))
        quote_volume = max(row.volume * row.close, Decimal("10000"))
        quantity = quote_volume * Decimal("0.01") / row.close
        ticker = Ticker(
            exchange=row.exchange,
            symbol=row.symbol,
            instrument_type=instrument_type,
            last_price=row.close,
            mark_price=row.close,
            index_price=row.close,
            best_bid=bid,
            best_ask=ask,
            volume_24h=quote_volume * Decimal("24"),
            timestamp=timestamp,
        )
        tickers.append(ticker)
        books[(row.exchange, row.symbol, instrument_type)] = OrderBook(
            exchange=row.exchange,
            symbol=row.symbol,
            instrument_type=instrument_type,
            bids=tuple(
                OrderBookLevel(
                    price=bid * (Decimal("1") - Decimal(level) * Decimal("0.0005")),
                    quantity=quantity,
                )
                for level in range(3)
            ),
            asks=tuple(
                OrderBookLevel(
                    price=ask * (Decimal("1") + Decimal(level) * Decimal("0.0005")),
                    quantity=quantity,
                )
                for level in range(3)
            ),
            timestamp=timestamp,
        )
        live_identities.add((row.exchange, row.symbol, instrument_type))
    active_instruments = [
        item
        for item in instruments
        if (item.exchange, item.exchange_symbol, item.instrument_type) in live_identities
    ]
    snapshots: list[FundingSnapshot] = []
    history: dict[tuple[str, str], list[FundingHistoryPoint]] = {}
    for item in active_instruments:
        if item.instrument_type is not InstrumentType.PERPETUAL:
            continue
        points = funding_by_symbol.get((item.exchange, item.exchange_symbol), [])
        past = [point for point in points if point.funding_timestamp <= timestamp]
        future = [point for point in points if point.funding_timestamp > timestamp]
        history[(item.exchange, item.exchange_symbol)] = past
        if not past:
            continue
        interval = Decimal(item.funding_interval or _infer_interval(points))
        snapshots.append(
            FundingSnapshot(
                exchange=item.exchange,
                symbol=item.exchange_symbol,
                funding_rate=past[-1].funding_rate,
                funding_interval_hours=interval,
                next_funding_time=future[0].funding_timestamp if future else None,
                mark_price=next(
                    (
                        ticker.last_price
                        for ticker in tickers
                        if ticker.exchange == item.exchange
                        and ticker.symbol == item.exchange_symbol
                    ),
                    None,
                ),
                timestamp=timestamp,
            )
        )
    return MarketSnapshot(
        instruments=active_instruments,
        tickers=tickers,
        funding=snapshots,
        orderbooks=books,
        captured_at=timestamp,
        funding_history=history,
        stale_after_seconds=3601,
    )


def _select_quote(
    opportunity: Opportunity,
    profile: str,
    available: Decimal,
    initial_capital: Decimal,
    positions: dict[str, _ReplayPosition],
    snapshot: MarketSnapshot,
    timestamp: datetime,
    risk_engine: RiskEngine,
    settings: Settings,
) -> SizeQuote | None:
    viable = [
        quote
        for quote in opportunity.size_quotes
        if quote.fully_filled and quote.net_profit > 0 and quote.capital <= available
    ]
    if profile == "baseline":
        return min(viable, key=lambda quote: abs(quote.capital - Decimal("250")), default=None)
    leg_venues = (opportunity.venue_a, opportunity.venue_b or opportunity.venue_a)
    venues = tuple(dict.fromkeys(leg_venues))
    asset_exposure = sum(
        (
            position.capital * Decimal(_venue_count(position.opportunity))
            for position in positions.values()
            if position.opportunity.asset == opportunity.asset
        ),
        Decimal("0"),
    )
    for quote in sorted(
        viable, key=lambda item: (item.net_profit, item.net_apr), reverse=True
    ):
        if not settlement_entry_allowed(
            opportunity,
            quote,
            snapshot,
            timestamp,
            settings.paper_entry_window_hours,
            settings.paper_min_settlement_cost_coverage,
        ):
            continue
        total_capital = quote.capital * Decimal(_venue_count(opportunity))
        assessments = [
            risk_engine.assess(
                opportunity,
                total_capital,
                initial_capital,
                asset_exposure=asset_exposure,
                exchange_exposure=_exchange_position_exposure(positions, venue),
                exchange_increment=quote.capital * Decimal(leg_venues.count(venue)),
                cash=available,
                cash_required=total_capital,
            )
            for venue in venues
        ]
        if all(assessment.approved for assessment in assessments):
            return quote
    return None


def _target_settlements(
    opportunity: Opportunity, snapshot: MarketSnapshot, timestamp: datetime
) -> tuple[datetime, ...]:
    return target_settlements(opportunity, snapshot, timestamp)


def _funding_payment(
    position: _ReplayPosition, point: FundingHistoryPoint
) -> Decimal | None:
    opportunity = position.opportunity
    if point.exchange == opportunity.venue_a and point.symbol == opportunity.symbol_a:
        side = opportunity.leg_a_side
    elif point.exchange == opportunity.venue_b and point.symbol == opportunity.symbol_b:
        side = opportunity.leg_b_side
    else:
        return None
    direction = Decimal("1") if side == "SELL" else Decimal("-1")
    return position.capital * point.funding_rate * direction


def _close_position(
    position: _ReplayPosition,
    timestamp: datetime,
    prices: dict[tuple[str, str, str], Decimal],
    events: list[BacktestEvent],
    attribution: dict[str, dict[str, dict[str, Decimal]]],
) -> Decimal:
    opportunity = position.opportunity
    exit_a = prices.get(
        (opportunity.venue_a, opportunity.symbol_a or "", opportunity.leg_a_type),
        position.entry_a,
    )
    exit_b = prices.get(
        (
            opportunity.venue_b or opportunity.venue_a,
            opportunity.symbol_b or "",
            opportunity.leg_b_type,
        ),
        position.entry_b,
    )
    pnl_a = _leg_pnl(position.capital, position.entry_a, exit_a, opportunity.leg_a_side)
    pnl_b = _leg_pnl(position.capital, position.entry_b, exit_b, opportunity.leg_b_side)
    quote = min(
        opportunity.size_quotes,
        key=lambda value: abs(value.capital - position.capital),
    )
    holding_hours = max(
        Decimal("0"),
        Decimal(str((timestamp - position.opened_at).total_seconds())) / Decimal("3600"),
    )
    borrow_cost = (
        quote.costs.borrowing_cost
        * holding_hours
        / opportunity.expected_holding_hours
    )
    market_pnl = pnl_a + pnl_b
    basis_pnl = (
        market_pnl
        if opportunity.strategy in {"spot_perp", "futures_basis"}
        else Decimal("0")
    )
    mismatch_pnl = market_pnl - basis_pnl
    components = {
        "funding_pnl": position.funding_pnl,
        "basis_pnl": basis_pnl,
        "price_mismatch_pnl": mismatch_pnl,
        "fees": position.entry_fees + quote.costs.exit_fees,
        "spread": position.entry_spread + quote.costs.exit_spread,
        "slippage": position.entry_slippage + quote.costs.exit_slippage,
        "borrow_cost": borrow_cost,
        "legging_cost": quote.costs.legging_cost,
        "other_costs": quote.costs.network_cost,
    }
    total_cost = sum(
        (
            components["fees"],
            components["spread"],
            components["slippage"],
            components["borrow_cost"],
            components["legging_cost"],
            components["other_costs"],
        ),
        Decimal("0"),
    )
    components["net_pnl"] = position.funding_pnl + market_pnl - total_cost
    _attribute_replay(attribution["strategy"], opportunity.strategy, components)
    _attribute_replay(attribution["asset"], opportunity.asset, components)
    venues = tuple(
        dict.fromkeys((opportunity.venue_a, opportunity.venue_b or opportunity.venue_a))
    )
    divisor = Decimal(len(venues))
    for venue in venues:
        _attribute_replay(
            attribution["exchange"],
            venue,
            {key: value / divisor for key, value in components.items()},
        )
    events.extend(
        [
            FillEvent(
                event_id=f"close:{position.position_id}",
                timestamp=timestamp,
                position_id=position.position_id,
                notional=position.capital * Decimal("2"),
                fee=quote.costs.exit_fees,
                spread=quote.costs.exit_spread,
                slippage=quote.costs.exit_slippage,
            ),
            PositionEvent(
                event_id=f"position-close:{position.position_id}",
                timestamp=timestamp,
                position_id=position.position_id,
                state="CLOSED",
                pnl=market_pnl - borrow_cost - quote.costs.network_cost,
            ),
        ]
    )
    exit_cost = (
        quote.costs.exit_fees
        + quote.costs.exit_spread
        + quote.costs.exit_slippage
        + borrow_cost
        + quote.costs.network_cost
    )
    return market_pnl - exit_cost


def _attribute_replay(
    target: dict[str, dict[str, Decimal]],
    key: str,
    components: dict[str, Decimal],
) -> None:
    bucket = target.setdefault(key, {})
    for component, value in components.items():
        bucket[component] = bucket.get(component, Decimal("0")) + value


def _leg_pnl(capital: Decimal, entry: Decimal, exit_price: Decimal, side: str) -> Decimal:
    quantity = capital / entry
    return (exit_price - entry) * quantity * (Decimal("1") if side == "BUY" else Decimal("-1"))


def _current_market_pnl(
    position: _ReplayPosition,
    prices: dict[tuple[str, str, str], Decimal],
) -> Decimal:
    opportunity = position.opportunity
    exit_a = prices.get(
        (opportunity.venue_a, opportunity.symbol_a or "", opportunity.leg_a_type),
        position.entry_a,
    )
    exit_b = prices.get(
        (
            opportunity.venue_b or opportunity.venue_a,
            opportunity.symbol_b or "",
            opportunity.leg_b_type,
        ),
        position.entry_b,
    )
    return _leg_pnl(
        position.capital, position.entry_a, exit_a, opportunity.leg_a_side
    ) + _leg_pnl(position.capital, position.entry_b, exit_b, opportunity.leg_b_side)


def _opportunity_key(opportunity: Opportunity) -> str:
    return "|".join(
        (
            opportunity.strategy,
            opportunity.asset,
            opportunity.venue_a,
            opportunity.venue_b or opportunity.venue_a,
            opportunity.symbol_a or "",
            opportunity.symbol_b or "",
            opportunity.leg_a_side,
            opportunity.leg_b_side,
        )
    )


def _funding_sign_changed(original: Opportunity, current: Opportunity) -> bool:
    return (original.funding_a >= 0) != (current.funding_a >= 0) or (
        original.funding_b >= 0
    ) != (current.funding_b >= 0)


def _venue_count(opportunity: Opportunity) -> int:
    return 2


def _exchange_position_exposure(
    positions: dict[str, _ReplayPosition], venue: str
) -> Decimal:
    return sum(
        (
            position.capital
            * Decimal(
                (
                    position.opportunity.venue_a,
                    position.opportunity.venue_b or position.opportunity.venue_a,
                ).count(venue)
            )
            for position in positions.values()
        ),
        Decimal("0"),
    )


def _infer_interval(points: list[FundingHistoryPoint]) -> int:
    if len(points) < 2:
        return 8
    deltas = sorted(
        max(1, round((right.funding_timestamp - left.funding_timestamp).total_seconds() / 3600))
        for left, right in zip(points, points[1:], strict=False)
    )
    return deltas[len(deltas) // 2]


def _instrument(row: InstrumentRecord) -> NormalizedInstrument:
    return NormalizedInstrument(
        exchange=row.exchange,
        exchange_symbol=row.exchange_symbol,
        base_asset=row.base_asset,
        quote_asset=row.quote_asset,
        instrument_type=InstrumentType(row.instrument_type),
        settlement_asset=row.settlement_asset,
        contract_size=row.contract_size,
        tick_size=row.tick_size,
        step_size=row.step_size,
        min_order_size=row.min_order_size,
        funding_interval=row.funding_interval,
        expiry=row.expiry,
        is_active=row.is_active,
    )


def _dataset_digest(
    candles: list[MarketCandleRecord], funding: list[FundingHistoryPoint]
) -> str:
    payload = [
        [
            "c",
            row.exchange,
            row.symbol,
            row.instrument_type,
            _utc(row.open_time).isoformat(),
            str(row.open),
            str(row.high),
            str(row.low),
            str(row.close),
            str(row.volume),
        ]
        for row in candles
    ]
    payload.extend(
        [
            "f",
            point.exchange,
            point.symbol,
            point.funding_timestamp.isoformat(),
            str(point.funding_rate),
            str(point.mark_price),
        ]
        for point in funding
    )
    encoded = json.dumps(payload, separators=(",", ":"), ensure_ascii=True).encode()
    return hashlib.sha256(encoded).hexdigest()


def _coverage(
    candles: list[MarketCandleRecord],
    funding: list[FundingHistoryPoint],
    start: datetime,
    end: datetime,
) -> dict[str, object]:
    grouped: dict[str, list[datetime]] = defaultdict(list)
    for row in candles:
        grouped[f"{row.exchange}:{row.symbol}:{row.instrument_type}"].append(_utc(row.close_time))
    expected = max(1, int((end - start).total_seconds() // 3600))
    series = {
        key: {
            "candles": len(values),
            "coverage_ratio": str(Decimal(len(set(values))) / Decimal(expected)),
            "largest_gap_hours": str(
                max(
                    (
                        Decimal(str((right - left).total_seconds())) / Decimal("3600")
                        for left, right in zip(
                            sorted(set(values)),
                            sorted(set(values))[1:],
                            strict=False,
                        )
                    ),
                    default=Decimal("0"),
                )
            ),
        }
        for key, values in sorted(grouped.items())
    }
    return {
        "start": start.isoformat(),
        "end": end.isoformat(),
        "candle_rows": len(candles),
        "funding_events": len(funding),
        "series": series,
    }


def _utc(value: datetime) -> datetime:
    return (value if value.tzinfo else value.replace(tzinfo=UTC)).astimezone(UTC)


def _candle_timestamp(candle: MarketCandleRecord) -> datetime:
    """Canonical close boundary independent of venue inclusive-end conventions."""

    return _utc(candle.open_time) + timedelta(minutes=candle.interval_minutes)
