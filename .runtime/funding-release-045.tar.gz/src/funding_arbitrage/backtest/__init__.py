"""Deterministic event-driven backtesting."""
