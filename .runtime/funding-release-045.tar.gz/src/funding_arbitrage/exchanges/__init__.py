"""Exchange adapters."""
